package com.example.campanasvp

import android.os.Bundle
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout
import androidx.viewpager.widget.ViewPager
import androidx.appcompat.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import com.example.campanasvp.ui.main.SectionsPagerAdapter
import com.example.campanasvp.databinding.ActivityMainMenuBinding
import com.example.campanasvp.ui.main.FormularioFragment
import com.example.campanasvp.Inspeccion

class MainMenu : AppCompatActivity() {

    private lateinit var binding: ActivityMainMenuBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val sectionsPagerAdapter = SectionsPagerAdapter(this, supportFragmentManager)
        val viewPager: ViewPager = binding.viewPager
        viewPager.adapter = sectionsPagerAdapter
        viewPager.offscreenPageLimit = 3
        val tabs: TabLayout = binding.tabs
        tabs.setupWithViewPager(viewPager)
        val fab: FloatingActionButton = binding.fab

        fab.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                .setAction("Action", null)
                .setAnchorView(R.id.fab).show()
        }


    }

    fun abrirFormularioConDatos(inspeccion: Inspeccion) {
        android.util.Log.d("MainMenu", "abrirFormularioConDatos llamado con ID ${inspeccion.id}")
        try {
            binding.viewPager.currentItem = 3
            val tag = "android:switcher:${R.id.view_pager}:3"
            val formularioFragment = supportFragmentManager.findFragmentByTag(tag)
            if (formularioFragment is FormularioFragment) {
                formularioFragment.cargarDatosInspeccion(inspeccion)
            } else {
                binding.viewPager.postDelayed({
                    val fragment = supportFragmentManager.findFragmentByTag(tag)
                    (fragment as? FormularioFragment)?.cargarDatosInspeccion(inspeccion)
                }, 100)
            }
        } catch (e: Exception) {
            android.util.Log.e("MainMenu", "Error al abrir formulario", e)
        }
    }
}